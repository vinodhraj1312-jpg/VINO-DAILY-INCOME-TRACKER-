# VINO Daily Income Tracker

A phone-friendly web app for tracking **earnings only** from Rapido, Uber and Ola. Includes daily, weekly and monthly totals, platform breakdown, entry history, delete and CSV export.

## Publish on GitHub Pages using your phone
1. Open your GitHub repository.
2. Tap **Add file → Upload files**.
3. Extract this ZIP on your phone first, then upload these five files from the extracted folder: `index.html`, `style.css`, `app.js`, `manifest.json`, `sw.js`. You may also upload `README.md`.
4. Tap **Commit changes** and commit to the `main` branch.
5. Open repository **Settings → Pages**.
6. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
7. Wait for GitHub Pages to publish. The app URL appears on the Pages screen.
8. Open that URL in Chrome on Android. Chrome menu → **Add to Home screen** or **Install app**.

## Data storage
Entries are saved in the browser on this device, not automatically synced to GitHub or another device. Use Export CSV regularly as a backup. Clearing browser data can erase entries.
